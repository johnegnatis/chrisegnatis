This was my first coding project ever which I made at age 15 to help me rationalize numbers for my geometry class.
This project is special to me because I used my (at the time) rudimentary understanding of java to create something useful.

How to use:
Open the executable jar file and enter a number. The program will take that number (i.e. 50) and return the true value of the square root of 50, its factors, and the number in its simplest form.

-John Egnatis